<?php 
    session_start();
    include 'koneksi.php';

?>
<!DOCTYPE html>
<html>
<head>
    <!-- Responsive -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js" ></script>

	<!-- Font Awesome -->
	<link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

	<!-- Data Tables -->
    <link href="datatables/datatables.css" rel="stylesheet">
    <script src=datatables/datatables.js></script>

    <title>Halaman Login</title>
</head>
<body>
    <style>



    </style>
    <div class="text-center mt-5 bg-primary">
    <div class="container-fluid bg-primary">
        <h1 class="mb-4">Halaman Login</h1>
        <form class="card-center bg-primary" action="" method="post">
            <label for="username">Username :</label>
            <input type="text" name="username" id="username"><br><br>
            <label for="password">Password :</label>
            <input type="password" name="password" id="password"><br><br>
            <button class="btn btn-success" type="submit" name="login">Login</button><br><br> 
        </form>
    </div>
    </div>
    

    <?php 
        if(isset($_POST['login'])){
            $username = $_POST['username'];
            $password = $_POST['password'];
            $query = mysqli_query($conn, "SELECT * FROM tb_admin WHERE username = '$username' AND password = md5('$password')");
            $cek = mysqli_num_rows($query);
            if($cek==1){
                $_SESSION['userweb']=$username;
                header("location: software_index.php");
                exit;
            } else {
                echo "Maaf username atau password anda salah";
            }
            
        }

    ?>
</body>
</html>