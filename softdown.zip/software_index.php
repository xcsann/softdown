<?php 
    include 'koneksi.php';
    session_start();

    $query = "SELECT * FROM tb_software WHERE id_software";
    $sql = mysqli_query($conn, $query);
    $id_software = 0;

?>

<!DOCTYPE html>

<!-- Halaman Untuk Kelola Buku -->
<html lang="en">
<head>
    <!-- RESPONSIVE -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.bundle.min.js"></script>

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="datatables/datatables.min.css">
    
    <title>Data Software</title>
</head>
<body>
    <div class="navbar navbar-light bg-primary">
        <nav class="container-fluid">
            <a class="navbar-brand">
                <strong>Welcome Admin!</strong>
            </a>
        </nav>
    </div>
    <div class="container-fluid">
        <h1>Data Software</h1>
        <figure>
            <blockquote class="blockquote">
                <p>Berisi data software yang telah disimpan di database.</p>
            </blockquote>
            <figcaption class="blockquote-footer"> 
                Softdown<cite> Situs download software yang aman, cepat, dan mudah.</cite>
            </figcaption>
        </figure>
    </div>
    <div class="container-fluid">
    <a href="software_kelola.php" type="button" class="btn btn-primary mb-3">
            <i class="fa fa-plus"></i> Tambah Software</a>
    <a href="logout.php" type="button" class="btn btn-danger mb-3">
            <i class="fa fa-reply"> Logout</i></a>
        <!-- ALERT -->
        <?php 
            if(isset($_SESSION['eksekusi'])):
        ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>
                <?php 
                    echo $_SESSION['eksekusi'];
                ?>
            </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php
            session_destroy();
            endif;
        ?>
        
        <div class="table-responsive">
            <table class="table align-middle table-bordered border-dark table-hover">
                <thead>
                    <tr>
                        <th><center>No.</center></th>
                        <th>Nama Software</th>
                        <th>Deskripsi</th>
                        <th>Link Download</th>
                        <th>Foto</th>
                        <th>Kategori</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <?php 
                    $query = "SELECT * FROM tb_software LEFT JOIN tb_kategori ON tb_software.id_kategori = tb_kategori.id_kategori";
                    $sql = mysqli_query($conn, $query);
                    $id_software = 0;
                ?>
                <tbody>
                    <?php 
                        while($result = mysqli_fetch_assoc($sql)){
                    ?>
                    <tr>
                        <td><center>
                            <?php echo ++$id_software; ?>.
                        </center></td>
                        <td><?php echo $result['nama_software']; ?></td>
                        <td><?php echo $result['deskripsi']; ?></td>
                        <td><?php echo $result['link_download']; ?></td>
                        <td>
                            <img src="gambar/<?php echo $result['gambar']; ?>" style="width: 50px;">
                        </td>
                        <td><?php echo $result['nama_kategori']; ?></td>
                        <td>
                            <a href="software_kelola.php?ubah=<?php echo $result['id_software'];?>" 
                            type="button" class="btn btn-danger btn-sm"><i class="fa fa-pencil"></i> Edit</a>

                            <a href="software_proses.php?hapus=<?php echo $result['id_software'];?>" 
                            type="button" class="btn btn-success btn-sm" 
                            onClick="return confirm('Apakah anda yakin ingin menghapus software tersebut???')">
                            <i class="fa fa-trash"></i> Hapus</a>
                        </td>
                    </tr>
                    <?php 
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>