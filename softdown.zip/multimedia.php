<?php
    include 'koneksi.php'; 
    //$query = "SELECT * FROM tb_software LEFT JOIN tb_kategori ON tb_software.id_kategori = tb_kategori.id_kategori";
    
?>

<!DOCTYPE html>
<html>
<head>
  <!-- Responsive -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/bootstrap.bundle.min.js" ></script>

	<!-- Font Awesome -->
	<link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

	<!-- Data Tables -->
  <link href="datatables/datatables.css" rel="stylesheet">
  <script src=datatables/datatables.js></script>

  <!-- Navbar Color -->
  <style>
    .navbar {
      background-color: aqua;
    }
  </style>

	<title>Multimedia - Softdown</title>
</head>

<body>
  
  <!-- Judul -->
	<div class="container">
    <div class="mt-2"></div>
		  <h1>SOFTDOWN</h1>
		  <figure>
	  	  <blockquote class="blockquote">
	        <p>Download Free Your Desired App</p>
	  	  </blockquote>
	    </figure>
    <div class="mb-3"></div>
  </div>

    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <div class="container">
          <a class="navbar-brand" href="index.php"><i class="fa fa-home"></i> HOME</a>
          <div class="collapse navbar-collapse" id="">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" href="productivity.php">Productivity</a></li>
                <li class="nav-item">
                <a class="nav-link" href="multimedia.php">Multimedia</a></li>
                <li class="nav-item">
                <a class="nav-link" href="os.php">Operating System</a></li>
                <li class="nav-item">
                <a class="nav-link" href="games.php">Games</a></li>
                <li class="nav-item">
                <a class="nav-link" href="tools.php">Tools</a></li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="home" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  About
                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li><a class="dropdown-item" href="request.php">Request</a></li>
                  <li><a class="dropdown-item" href="contact.php">Contact</a></li>
                  <li><a class="dropdown-item" href="adminprofile.php">Admin Profile</a></li>
                  <li><a class="dropdown-item" href="subscribe.php">Subscribe</a></li>
                </ul>
              </li>
            </ul>
            <form class="d-flex">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-light me-2" type="submit"><i class="fa fa-search"></i></button>
              <a href="login.php" type="submit" class="btn btn-primary me-2"><i class="fa fa-user-circle"></i></a>
            </form>
          </div>
        </div>
      </nav>
    </nav>
  </nav>
  <!-- Jumbotron -->
  <div id="intro" class="p-5 text-center bg-light">
      <h1 class="mb-3 h2">Welcome To Multimedia Apps</h1>
      <p class="mb-3">Create Your Creative</p>
      <a class="btn btn-primary m-2" href="softdown" role="button" rel="nofollow"
        target="_blank">Website</a>
      <a class="btn btn-primary m-2" href="tutorial.php" target="_blank"
        role="button">How To Download</a>
    </div>
    <!-- Jumbotron -->

  </header>
  <!--Main Navigation-->

  <!--Main layout-->
  <main class="my-5">
    <div class="container">
      <!--Section: Content-->
      <section class="text-center">
        <h4 class="mb-5"><strong>Multimedia</strong></h4>

        <div class="row">
        <?php
          $query = "SELECT * FROM tb_software WHERE id_kategori = 2;";
          $sql = mysqli_query($conn, $query);
          while($result = mysqli_fetch_assoc($sql)){
        ?>
          <div class="col-lg-4 col-md-12 mb-4">
            <div class="card">
              <div class="bg-image hover-overlay ripple mt-4" data-mdb-ripple-color="light">
                <img src="gambar/<?php echo $result['gambar']; ?>" style="width: 150px;" class="img-fluid mb-3" class="rounded"/>
                  <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                </a>
              </div>
              <div class="card-body mb-3">
                <h5 class="card-title"><?php echo $result['nama_software']; ?></h5>
                <p class="card-text"><?php echo $result['deskripsi']; ?></p>
                <a href="<?php echo $result['link_download']; ?>" class="btn btn-primary">Download</a>
              </div>
            </div>
          </div>
        <?php 
            }
        ?>
        </div>

        

      </section>
      <!--Section: Content-->

  <!--Footer-->
  <footer class="bg-light text-lg-start">
    <div class="py-4 text-center">
      <a role="button" class="btn btn-primary btn-lg m-2"
        href="https://getbootstrap.com" rel="nofollow" target="_blank">
        Belajar Bootstrap 5
      </a>
      <a role="button" class="btn btn-primary btn-lg m-2" href="latestpost" target="_blank">
        Artikel Terbaru
      </a>
    </div>

    <hr class="m-0" />

    <div class="text-center py-4 align-items-center">
      <p>Follow Softdown</p>
      <a href="https://www.youtube.com" class="btn btn-primary m-1" role="button"
        rel="nofollow" target="_blank">
        <i class="fa fa-youtube"></i>
      </a>
      <a href="https://www.facebook.com" class="btn btn-primary m-1" role="button" rel="nofollow"
        target="_blank">
        <i class="fa fa-facebook"></i>
      </a>
      <a href="https://twitter.com" class="btn btn-primary m-1" role="button" rel="nofollow"
        target="_blank">
        <i class="fa fa-twitter"></i>
      </a>
      <a href="https://github.com" class="btn btn-primary m-1" role="button" rel="nofollow"
        target="_blank">
        <i class="fa fa-github"></i>
      </a>
    </div>

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2022 Copyright:
      <a class="text-dark" href="https://softdown.com/">SoftDown</a>
    </div>
    <!-- Copyright -->
  </footer>
</body>
</html>
