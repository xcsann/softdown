<?php 
    session_start();
    $_SESSION['userweb']="";
    header( "location:index.php");
    exit;
?>