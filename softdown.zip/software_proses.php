<?php
    include 'software_fungsi.php';
    session_start();

    if(isset($_POST['aksi'])){
        if($_POST['aksi'] == "add"){

            $berhasil = tambah($_POST, $_FILES);

            if($berhasil){
                $_SESSION['eksekusi'] = "Software Berhasil Ditambahkan!";
                header("location: software_index.php");
            } else {
                echo $berhasil;
            }
            
        } else if($_POST['aksi'] == "edit"){

            $berhasil = ubah($_POST, $_FILES);

            if($berhasil){
                $_SESSION['eksekusi'] = "Software Berhasil Diperbarui!";
                header("location: software_index.php");
            } else {
                echo $berhasil;
            }
        }
    }

    if(isset($_GET['hapus'])){
        
        $berhasil = hapus($_GET);
        
        if($berhasil){
            $_SESSION['eksekusi'] = "Software Berhasil Dihapus!";
            header("location: software_index.php");
        } else {
            echo $berhasil;
        }
    }
?>