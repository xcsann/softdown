<?php
    include 'koneksi.php';
    session_start();
    
    $query = "SELECT * FROM tb_software";
	$sql = mysqli_query($conn, $query);
    while($result = mysqli_fetch_assoc($sql)){
        $id_software = $result;
	}
        $nama_software = '';
        $deskripsi = '';
        $link_download = '';
        $gambar = '';
        $id_kategori = '';

    if(isset($_GET['ubah'])){
        $id_software = $_GET['ubah'];

        $query = "SELECT * FROM tb_software WHERE id_software = '$id_software';";
        $sql = mysqli_query($conn, $query);

        $result = mysqli_fetch_assoc($sql);

        $nama_software = $result['nama_software'];
        $deskripsi = $result['deskripsi'];
        $link_download = $result['link_download'];
        $gambar = $result['gambar'];
        $id_kategori = $result['id_kategori'];

    
    } 

?>


<!DOCTYPE html>

<!-- Halaman Untuk Mengelola Buku -->
<html>
<head>
    <!-- RESPONSIVE -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.bundle.min.js"></script>

    <!-- FONT AWESOME -->
    <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="datatables/datatables.min.css">
    
    <title>Kelola Software</title>
</head>
<body>
    <div class="navbar navbar-light bg-primary">
        <nav class="container-fluid">
            <a class="navbar-brand">
                <strong>Data Software</strong>
            </a>
        </nav>
    </div>
    <div class="container mt-3">
        <form method="POST" action="software_proses.php" enctype="multipart/form-data">
            <input type="hidden" value="<?php echo $id_software ?>" name="id_software">
            <div class="mb-3 row">
                <label for="nama_software" class="col-sm-2 col-form-label">
                    Nama Software
                </label>
                <div class="col-sm-10">
                    <input required type="text" name="nama_software" class="form-control" id="nama_software" placeholder="Example : Virtual Box" value="<?php echo $nama_software; ?>">
                </div>
            </div>
            <input type="hidden" value="<?php echo $deskripsi ?>" name="deskripsi">
            <div class="mb-3 row">
                <label for="deskripsi" class="col-sm-2 col-form-label">
                    Deskripsi
                </label>
                <div class="col-sm-10">
                    <input required type="text" name="deskripsi" class="form-control" id="deskripsi" placeholder="Example : Download Virtual Box Terbaru" value="<?php echo $deskripsi; ?>">
                </div>
            </div>
            <input type="hidden" value="<?php echo $link_download ?>" name="link_download">
            <div class="mb-3 row">
                <label for="link_download" class="col-sm-2 col-form-label">
                    Link Download
                </label>
                <div class="col-sm-10">
                    <input required type="text" name="link_download" class="form-control" id="link_download" placeholder="Example : https://www.idm.download.com" value="<?php echo $link_download; ?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="gambar" class="col-sm-2 col-form-label">
                    Gambar
                </label>
                <div class="col-sm-10"><input <?php if(!isset($_GET['ubah'])){ echo "required";} ?> class="form-control" type="file" name="gambar" id="gambar" accept="image/*"></div>
            </div>
            <div class="mb-3 row">
                <label for="id_kategori" class="col-sm-2 col-form-label">
                    Kategori
                </label>
                <div class="col-sm-10">
                <?php 
                    $query = "SELECT * FROM tb_kategori WHERE id_kategori";
                    $sql = mysqli_query($conn, $query);
                    $id_software = 0;
                ?>
                    <select id="id_kategori" required name="id_kategori" class="form-select">
                        <option value="">Pilih Kategori</option>
                        <?php 
                            while($result = mysqli_fetch_assoc($sql)){
                        ?>
                        <option value="<?php echo $result['id_kategori']?>">
                            <?php echo $result['nama_kategori']?>
                        </option>
                        <?php 
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col">
                    <?php 
                        if(isset($_GET['ubah'])){
                    ?>
                        <button type="submit" name="aksi" value="edit" class="btn btn-primary">
                            <i class="fa fa-save"></i> Simpan</button>
                    <?php 
                        } else {
                    ?> 
                        <button type="submit" name="aksi" value="add" class="btn btn-primary">
                            <i class="fa fa-save"></i> Tambahkan</button>     
                    <?php 
                        }
                    ?>
                        <a href="software_index.php" type="button" class="btn btn-danger"><i class="fa fa-reply"></i> Batal</a>
                </div>  
            </div>
        </form>
    </div>
</body>
</html>