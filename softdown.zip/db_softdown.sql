-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 09, 2022 at 01:37 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_softdown`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(3) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id_software` int(3) NOT NULL,
  `id_kategori` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password`, `id_software`, `id_kategori`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 1, 0),
(3, 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE `tb_kategori` (
  `id_kategori` int(3) NOT NULL,
  `nama_kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Productivity'),
(2, 'Multimedia'),
(3, 'Operating System'),
(4, 'Games'),
(5, 'Tools');

-- --------------------------------------------------------

--
-- Table structure for table `tb_software`
--

CREATE TABLE `tb_software` (
  `id_software` int(3) NOT NULL,
  `nama_software` varchar(50) NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `link_download` varchar(100) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  `id_kategori` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_software`
--

INSERT INTO `tb_software` (`id_software`, `nama_software`, `deskripsi`, `link_download`, `gambar`, `id_kategori`) VALUES
(16, 'Sublime Text 3', 'Download Sublime Text 3 Terbaru', 'https://www.mediafire.com/file/a0vuov0j0lf8637/Sublime_Text_Build_3211_x64.zip/file', 'Sublime_Text_3_logo.png', 1),
(17, 'IDM', 'Internet Download Manager Terbaru', 'https://www.mediafire.com/file/mssac4jfb8duxqh/IDM.6.39.zip/file', '17.jpg', 5),
(18, 'XAMPP', 'Download xampp versi 7.4.12', 'https://www.mediafire.com/file/fi6wvkyw95ha8ca/xampp-windows-x64-7.4.12-0-VC15-installer.exe/file', '18.png', 1),
(19, 'Debian 10', 'Download Debian 10.11 netinstall', 'https://www.mediafire.com/file/sh6kk6ofrqlw438/debian-10.11.0-i386-netinst.iso/file', '19.png', 3),
(20, 'Cisco Packet Tracer', 'Download Cisco Packet Tracer Terbaru', 'https://www.mediafire.com/file/pl0obofulmf954v/CiscoPacketTracer_801_Windows_64bit_setup.exe/file', '20.png', 1),
(25, 'WinRAR 64bit', 'Download WinRAR v.602 64bit', 'https://www.mediafire.com/file/r1ucix24szszcim/winrar-x64-602.exe/file', '25.png', 5),
(26, 'Ventoy', 'Download Ventoy Bootable v1.0.57', 'https://www.mediafire.com/file/e67pabvyr6e26zk/ventoy-1.0.57-windows.zip/file', '26.png', 5),
(27, 'Minecraft Windows 10 Free Edition', 'Download Minecraft Windows 10 Free Edition', 'https://www.mediafire.com/file/sspa4661ykrgv4h/Minecraft.Windows.10.Edition.zip/file', '27.jpg', 4),
(28, 'Briker 2.1.1', 'Download Briker v2.1.1 iso file', 'https://www.mediafire.com/file/u9xmuw6t1q4rxz4/briker-2.1.1.iso/file', '28.jpg', 3),
(29, 'Adobe Photoshop CS6 ', 'Download Adobe Photoshop CS6', 'https://mega.nz/file/x6QwDTDI#hlMjPleMvpOBv3kvLTKAln96UfHTzkn8W2J4gzcYpEo', '29.png', 2),
(30, 'Camtasia 2020', 'Download Camtasia 2020 20.0.13', 'https://mega.nz/file/JqgywDrI#kLoAFMtrjEUWR0cfLSDI5GLjr-jkOjsghKtJPeuPiKY', '30.jpg', 2),
(31, 'Proxmox VE', 'Download Proxmox VE 7.0.2 iso file', 'https://www.mediafire.com/file/yhy7x7j7oxip7h4/proxmox-ve_7.0-2.iso/file', '31.png', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD KEY `id_software` (`id_software`);

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_software`
--
ALTER TABLE `tb_software`
  ADD PRIMARY KEY (`id_software`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
  MODIFY `id_kategori` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_software`
--
ALTER TABLE `tb_software`
  MODIFY `id_software` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD CONSTRAINT `tb_admin_ibfk_1` FOREIGN KEY (`id_software`) REFERENCES `tb_admin` (`id_admin`);

--
-- Constraints for table `tb_software`
--
ALTER TABLE `tb_software`
  ADD CONSTRAINT `tb_software_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `tb_kategori` (`id_kategori`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
