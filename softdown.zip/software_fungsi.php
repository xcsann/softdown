<?php 
    include 'koneksi.php';

    //Tambah Data//
    function tambah($data, $files){

        $id_software = $data['id_software'];
        $nama_software = $data['nama_software'];
        $deskripsi = $data['deskripsi'];
        $link_download = $data['link_download'];
        $id_kategori = $data['id_kategori'];

        $split = explode('.', $files['gambar']['name']);

        $ekstensi = $split[count($split)-1];
        

        $query = "INSERT INTO tb_software VALUES(null, '$nama_software', '$deskripsi', '$link_download', '-', $id_kategori)";
        $sql = mysqli_query($GLOBALS['conn'], $query);

        $query2 = "SELECT * FROM tb_software ORDER BY id_software DESC limit 1 ;";
        $sql2 = mysqli_query($GLOBALS['conn'], $query2);
        $result = mysqli_fetch_assoc($sql2);

        $gambar = $result['id_software'].'.'.$ekstensi;
        $dir = "gambar/";
        
        $id = $result['id_software'];
        $tmpFile = $_FILES['gambar']['tmp_name'];

        move_uploaded_file($tmpFile, $dir.$gambar);

        
        $query3 = "UPDATE tb_software SET gambar = '$gambar' WHERE id_software = $id ;";
        $sql3 = mysqli_query($GLOBALS['conn'], $query3);
        return true;
    }

    //Ubah Data//
    function ubah($data, $files){
        $id_software = $data['id_software'];
        $nama_software = $data['nama_software'];
        $deskripsi = $data['deskripsi'];
        $link_download = $data['link_download'];
        $id_kategori = $data['id_kategori'];

        $queryShow = "SELECT * FROM tb_software WHERE id_software = $id_software";
        $sqlShow = mysqli_query($GLOBALS['conn'], $queryShow);
        $result = mysqli_fetch_assoc($sqlShow);

        if($files['gambar']['name'] == ""){
            $gambar = $result['gambar'];
        } else {
            $gambar = $files['gambar']['name'];
            unlink("gambar/".$result['gambar']);
            move_uploaded_file($files['gambar']['tmp_name'], 'gambar/'.$files['gambar']['name']);
        }
            $query = "UPDATE tb_software SET nama_software='$nama_software', deskripsi='$deskripsi', link_download='$link_download', gambar='$gambar', id_kategori='$id_kategori'  WHERE id_software='$id_software';";
            $sqlShow = mysqli_query($GLOBALS['conn'], $query);

            return true;
    }

    //Hapus Data//
    function hapus($data){
        $id_software = $data['hapus'];

        $queryShow = "SELECT * FROM tb_software WHERE id_software = $id_software";
        $sqlShow = mysqli_query($GLOBALS['conn'], $queryShow);
        $result = mysqli_fetch_assoc($sqlShow);


        unlink("gambar/".$result['gambar']);

        $query = "DELETE FROM tb_software WHERE id_software = '$id_software';";
        $sqlShow = mysqli_query($GLOBALS['conn'], $query);

        return true;
    }


?>